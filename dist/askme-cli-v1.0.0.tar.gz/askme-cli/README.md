# AskMe CLI v1.0.0

## Quick Start
1. Make executable: chmod +x bin/askme
2. Add to PATH or run directly: ./bin/askme "your question"
3. Configure API keys: ./bin/askme --setup

## Documentation
Visit: https://github.com/vn6295337/askme
